======================================
Welcome to BEAR(TM) installer package!


BEAR was developed by Eugenio Mattei

Centre for Molecular Bioinformatics
University of Rome "Tor Vergata"

March 21st, 2014

[version_number] = 1.0
======================================

Thank you for trying BEAR.
This document contains the instruction on BEAR installation/setup and some useful information on the software.

========
Contents
========
I.	Operating Environment
II.	Installation
III.	Running
IV. 	Input/Output Format
V. 	Useful Information
VI.	Citing us


==================================
I.	Operating Environment
------------------------------------------------------------
- Linux
- Windows
- MacOSX


====================================
II.	Installation
---------------------------------------------------------------
No installation is needed but Java needs to be installed on the computer

==================================
III. Running
------------------------------------------------------------
To run BEAR encoder type on your terminal:

java -jar BEAR_Encoder.jar <input> <output>

The programm will read your sequences from file called <input> and will write the resulting encoding in the file called <output>.
For more information files format please see next section.
 
==================================
IV. Input/Output Format
------------------------------------------------------------
--------
Input
--------
The input file must be formatted using the FASTA format:
-The line containing the name and/or the description of the sequence start with a ">"
-The words following the ">" are interpreted as nucleotides of the sequence.
-The words following the nucleotides are interpreted as secondary structure information

The IUPAC notation is accepted for nucleotides (case-insensitive).
The secondaty structure must be supplied using dot-bracket notation; only '( . )' characters will be accepted by the program.

Example of a well formatted input file:
>X06054.1/711637
GGGCCCGUCGUCUAGCCUGGUUAGGACGCUGCCCUGACGCGGCAGAAAUCCUGGGUUCAAGUCCCAGCGGGCCCA
(((((((..((((..........)))).(((((.......))))).....(((((.......)))))))))))).

It is possible to put many input sequences in the same file e.g. :
>X06054.1/711637
GGGCCCGUCGUCUAGCCUGGUUAGGACGCUGCCCUGACGCGGCAGAAAUCCUGGGUUCAAGUCCCAGCGGGCCCA
(((((((..((((..........)))).(((((.......))))).....(((((.......)))))))))))).
>AP000063.1/5917959095
GCGGGGGUGCCCGAGCCUGGCCAAAGGGGUCGGGCUCAGGACCCGAUGGCGUAGGCCUGCGUGGGUUCAAAUCCCACCCCCCGCA
(((((((..(((.............))).(((((.......)))))..............(((((.......)))))))))))).
>AP000989.1/7327973354
GCGGCCGUCGUCUAGUCUGGAUUAGGACGCUGGCCUUCCAAGCCAGUAAUCCCGGGUUCAAAUCCCGGCGGCCGCA
(((((((..((((...........)))).(((((.......))))).....(((((.......)))))))))))).
>AE006696.1/291218
GCCGCCGUAGCUCAGCCCGGGAGAGCGCCCGGCUGAAGACCGGGUUGUCCGGGGUUCAAGUCCCCGCGGCGGCA
(((((((..((((.........)))).(((((.......))))).....(((((.......)))))))))))).

--------
Output
--------

The resulting output file will be formatted as a FASTA file with and additional line containing BEAR encoding:

>X06054.1/711637
GGGCCCGUCGUCUAGCCUGGUUAGGACGCUGCCCUGACGCGGCAGAAAUCCUGGGUUCAAGUCCCAGCGGGCCCA
(((((((..((((..........)))).(((((.......))))).....(((((.......)))))))))))).
GGGGGGG::ddddssssssssssdddd:eeeeepppppppeeeee:::::eeeeepppppppeeeeeGGGGGGG:
>AP000063.1/5917959095
GCGGGGGUGCCCGAGCCUGGCCAAAGGGGUCGGGCUCAGGACCCGAUGGCGUAGGCCUGCGUGGGUUCAAAUCCCACCCCCCGCA
(((((((..(((.............))).(((((.......)))))..............(((((.......)))))))))))).
GGGGGGG::cccvvvvvvvvvvvvvccc:eeeeepppppppeeeee::::::::::::::eeeeepppppppeeeeeGGGGGGG:
>AP000989.1/7327973354
GCGGCCGUCGUCUAGUCUGGAUUAGGACGCUGGCCUUCCAAGCCAGUAAUCCCGGGUUCAAAUCCCGGCGGCCGCA
(((((((..((((...........)))).(((((.......))))).....(((((.......)))))))))))).
GGGGGGG::ddddtttttttttttdddd:eeeeepppppppeeeee:::::eeeeepppppppeeeeeGGGGGGG:
>AE006696.1/291218
GCCGCCGUAGCUCAGCCCGGGAGAGCGCCCGGCUGAAGACCGGGUUGUCCGGGGUUCAAGUCCCCGCGGCGGCA
(((((((..((((.........)))).(((((.......))))).....(((((.......)))))))))))).
GGGGGGG::ddddrrrrrrrrrdddd:eeeeepppppppeeeee:::::eeeeepppppppeeeeeGGGGGGG:

====================================
V. Citing us
----------------------------------------------------------------
If you use this tool please remember to cite us :


For questions, support, bug reports, proposals, cooperations
or any other communication, feel free to mail me at eugenio.mattei@uniroma2.it

For more information please refer to 
bioinformatica.uniroma2.it/BEAR/Documentation.php

------------------------------------------------------------------------------------------------------------
Copyright 2014 Centre for Molecular Bioinformatics, University of Rome "Tor Vergata"
